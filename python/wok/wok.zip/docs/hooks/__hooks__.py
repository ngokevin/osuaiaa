from wok.contrib.hooks import HeadingAnchors

hooks = {
    'page.template.post': [ HeadingAnchors() ],
}
