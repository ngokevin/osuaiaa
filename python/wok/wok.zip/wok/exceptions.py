class DependencyException(Exception):
    pass
